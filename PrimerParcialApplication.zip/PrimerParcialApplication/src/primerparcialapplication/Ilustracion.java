package primerparcialapplication;

public class Ilustracion extends Publicacion {
    
    private String nombreIlustrador;
    private double ancho;
    private double alto;

    public Ilustracion(String nombreIlustrador, double ancho, double alto, String titulo, int añoPublicacion) {
        super(titulo, añoPublicacion);
        this.nombreIlustrador = nombreIlustrador;
        this.ancho = ancho;
        this.alto = alto;
    }
    
    @Override
    public void leer() {
        System.out.println("No se puede leer la ilustración '" + getTitulo() + "'.");
    } 
    
    @Override
    public String toString() {
        return "Ilustración: '" + getTitulo() + "' de " + nombreIlustrador + " (Año: " + getAñoPublicacion() + ", Dimensiones: " + ancho + "x" + alto + ")";
    }

    
    public String getNombreIlustrador() {
        return nombreIlustrador;
    }

    public double getAncho() {
        return ancho;
    }

    public double getAlto() {
        return alto;
    }  
}
