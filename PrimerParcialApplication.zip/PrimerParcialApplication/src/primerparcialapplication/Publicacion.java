package primerparcialapplication;

public abstract class Publicacion {

    private String titulo;
    private int añoPublicacion;

    public Publicacion(String titulo, int añoPublicacion) {
        this.titulo = titulo;
        this.añoPublicacion = añoPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getAñoPublicacion() {
        return añoPublicacion;
    }

    public abstract void leer();
}
