package primerparcialapplication;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    // Lista que almacena las publicaciones de la biblioteca
    private List<Publicacion> publicaciones;

    // Constructor que inicializa la lista de publicaciones
    public Biblioteca() {
        publicaciones = new ArrayList<>();
    }

    // Método para agregar una publicacion a la biblioteca
    public void agregarPublicacion(Publicacion publicacion) throws PublicacionDuplicadaException {
        // Verifica si la publicacion ya existe
        for (Publicacion p : publicaciones) {
            if (p.getTitulo().equals(publicacion.getTitulo()) && p.getAñoPublicacion() == publicacion.getAñoPublicacion()) {
                // Lanza una excepcion si la publicacion ya existe
                throw new PublicacionDuplicadaException("La publicacion '" + publicacion.getTitulo() + "' ya existe.");
            }
        }
        // Agrega la publicacion a la lista si no existe
        publicaciones.add(publicacion);
    }

    // Método para mostrar todas las publicaciones
    public void mostrarPublicaciones() {
        // Verifica si hay publicaciones
        if (publicaciones.isEmpty()) {
            System.out.println("No hay publicaciones en la biblioteca.");
            return;
        }
        
        // Muestra cada publicacion en la lista
        for (Publicacion p : publicaciones) {
            System.out.println(p.toString());
        }
    }

    // Método para leer las publicaciones que son leíbles (libros y revistas)
    public void leerPublicaciones() {
        boolean hayPublicacionesLeibles = false; // Bandera para verificar si hay publicaciones leíbles

        // Itera sobre cada publicacion en la lista
        for (Publicacion p : publicaciones) {
            // Verifica si la publicacion es un libro o una revista
            if (p instanceof Libro || p instanceof Revista) {
                p.leer(); // Llama al método leer de la publicacion
                hayPublicacionesLeibles = true; // Marca que hay publicaciones leíbles
            } else {
                // Informa que las ilustraciones no son leíbles
                System.out.println("La ilustracion '" + p.getTitulo() + "' no se puede leer.");
            }
        }

        // Informa si no hay publicaciones leíbles
        if (!hayPublicacionesLeibles) {
            System.out.println("No hay publicaciones leíbles en la biblioteca.");
        }
    }
}
