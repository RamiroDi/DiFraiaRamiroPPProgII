package primerparcialapplication;

public class Revista extends Publicacion {
    
    private int numeroEdicion;

    public Revista(int numeroEdicion, String titulo, int añoPublicacion) {
        super(titulo, añoPublicacion);
        this.numeroEdicion = numeroEdicion;
    }
    
    @Override
    public void leer() {
        System.out.println("Leyendo la revista '" + getTitulo() + "' (Edicion " + numeroEdicion + ").");
    }
    
    @Override
    public String toString() {
        return "Revista: '" + getTitulo() + "' (Año: " + getAñoPublicacion() + ", Edicion: " + numeroEdicion + ")";
    }

    
    public int getNumeroEdicion() {
        return numeroEdicion;
    }
}
