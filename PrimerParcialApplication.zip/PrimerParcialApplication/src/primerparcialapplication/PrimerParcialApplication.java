package primerparcialapplication;

public class PrimerParcialApplication {

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

        try {
            // Agregamos algunas publicaciones
            biblioteca.agregarPublicacion(new Libro("Gabriel Garcia Marquez", Genero.FICCION, "Cien años de soledad", 1967));
            biblioteca.agregarPublicacion(new Revista(42, "National Geographic", 2020));
            biblioteca.agregarPublicacion(new Ilustracion("Pablo Picasso", 20.5, 30.5, "Guernica", 1937));

            // Intentamos agregar una publicación duplicada
            biblioteca.agregarPublicacion(new Libro("Gabriel García Marquez", Genero.FICCION, "Cien años de soledad", 1967));
        } catch (PublicacionDuplicadaException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Mas pruebas: Agregar otras publicaciones
        try {
            biblioteca.agregarPublicacion(new Libro("George Orwell", Genero.FICCION, "1984", 1949));
            biblioteca.agregarPublicacion(new Revista(101, "Scientific American", 2021));
            biblioteca.agregarPublicacion(new Ilustracion("Vincent van Gogh", 30.0, 40.0, "La noche estrellada", 1889));

            // Intentar agregar otra publicación duplicada
            biblioteca.agregarPublicacion(new Revista(42, "National Geographic", 2020)); // Duplicado
        } catch (PublicacionDuplicadaException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Muestra todas las publicaciones
        System.out.println("Publicaciones en la biblioteca:");
        biblioteca.mostrarPublicaciones();

        // Lee publicaciones
        System.out.println("\nLectura de publicaciones:");
        biblioteca.leerPublicaciones();

        // Agregar mas pruebas para ilustraciones
        try {
            biblioteca.agregarPublicacion(new Ilustracion("Leonardo da Vinci", 25.0, 35.0, "La Mona Lisa", 1503));
        } catch (PublicacionDuplicadaException e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        // Llamar a leerPublicaciones nuevamente para ver cómo se comporta con la nueva ilustración
        System.out.println("\nLectura de publicaciones despues de agregar 'La Mona Lisa':");
        biblioteca.leerPublicaciones();
    }
}
