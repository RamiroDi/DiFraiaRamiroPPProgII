package primerparcialapplication;

public class Libro extends Publicacion {
    
    private String autor;
    private Genero genero;

    public Libro(String autor, Genero genero, String titulo, int añoPublicacion) {
        super(titulo, añoPublicacion);
        this.autor = autor;
        this.genero = genero;
    }
    
    @Override
    public void leer() {
        System.out.println("Leyendo el libro '" + getTitulo() + "' de " + autor + " (" + genero + ").");
    }

    @Override
    public String toString() {
        return "Libro: '" + getTitulo() + "' de " + autor + " (Año: " + getAñoPublicacion() + ", Género: " + genero + ")";
    }

    
    public String getAutor() {
        return autor;
    }

    public Genero getGenero() {
        return genero;
    }
}
