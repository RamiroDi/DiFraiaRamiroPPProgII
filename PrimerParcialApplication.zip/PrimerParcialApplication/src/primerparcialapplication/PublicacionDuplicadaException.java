package primerparcialapplication;

public class PublicacionDuplicadaException extends Exception {

    public PublicacionDuplicadaException() {
        super("La publicación ya existe en la biblioteca.");
    }

    public PublicacionDuplicadaException(String msg) {
        super(msg);
    }
}
